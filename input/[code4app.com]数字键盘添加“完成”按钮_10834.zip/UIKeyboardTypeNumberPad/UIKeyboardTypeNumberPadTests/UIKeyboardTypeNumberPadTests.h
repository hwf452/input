//
//  UIKeyboardTypeNumberPadTests.h
//  UIKeyboardTypeNumberPadTests
//
//  Created by 斌 on 12-9-26.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface UIKeyboardTypeNumberPadTests : SenTestCase

@end
