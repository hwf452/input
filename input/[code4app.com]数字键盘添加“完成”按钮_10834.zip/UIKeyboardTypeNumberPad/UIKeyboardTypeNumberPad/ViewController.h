//
//  ViewController.h
//  UIKeyboardTypeNumberPad
//
//  Created by 斌 on 12-9-26.
//  Copyright (c) 2012年 斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{

    UIButton *doneInKeyboardButton;
}

- (IBAction)NOBut:(id)sender;
- (IBAction)But:(id)sender;
@end
