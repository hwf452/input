//
//  RootViewController.h
//  KeyBoardTest
//
//  Created by apple on 14-6-13.
//  Copyright (c) 2014年 kongyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@property(retain,nonatomic)UITextField * txt;

@end
