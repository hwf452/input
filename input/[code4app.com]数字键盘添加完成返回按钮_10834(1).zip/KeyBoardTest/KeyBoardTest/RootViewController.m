//
//  RootViewController.m
//  KeyBoardTest
//
//  Created by apple on 14-6-13.
//  Copyright (c) 2014年 kongyu. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UITextField * txtField = [[UITextField alloc]initWithFrame:CGRectMake(20, 60, 200, 40)];
    txtField.backgroundColor = [UIColor redColor];
    txtField.keyboardType = UIKeyboardTypeNumberPad;
//    txtField.returnKeyType = UIReturnKeyGo;
    self.txt = txtField;
    [self.view addSubview:txtField];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShowOnDelay:) name:UIKeyboardWillShowNotification object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)keyboardWillShowOnDelay:(NSNotification *)notification
{
    [self performSelector:@selector(keyboardWillShow:) withObject:nil afterDelay:0];
}

- (void)keyboardWillShow:(NSNotification *)notification
{
    UIButton *doneButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 163, 106, 53)];
    [doneButton setTitle:@"Done" forState:(UIControlStateNormal)];
    [doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
    UIWindow * tempWindow = [[[UIApplication sharedApplication]windows]objectAtIndex:1];
    UIView * keyBoard = nil;
    NSLog(@"%@",tempWindow);
    for (int i = 0; i < tempWindow.subviews.count; i ++) {
        keyBoard = [tempWindow.subviews objectAtIndex:i];
        
        [keyBoard addSubview:doneButton];
    }

}


#pragma mark -
- (void)doneButton:(UIButton *)btn{
//    NSLog(@"kongyu");
    [self.txt resignFirstResponder];
}
@end
