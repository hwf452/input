//
//  AppDelegate.h
//  ZenKeyboardDemo
//
//  Created by Mac on 13-7-8.
//  Copyright (c) 2013年 iiii1314iiii@qq.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
